'''
	Greenhouse Automation script
'''
import logging
from logging.config import dictConfig
import sqlite3
#import RPi.GPIO as GPIO
import time
from flask import Flask, render_template, request, jsonify, request, url_for, flash, redirect, session, abort
#from gpiozero import CPUTemperature
import uuid
import os
import json
import subprocess
import string
from datetime import datetime

current_date_and_time = datetime.now()

app = Flask(__name__)
 
app.config['SECRET_KEY'] = '12345'

    
@app.route("/")
def index():
	templateData = {
		'title' : 'GPIO Relay Status!',
		'cputemp'  : 110,
		'valvestemp_data' : 72,
		'headtemp_data' : 72,
		'moist_soil_1' : 0,
		'moist_soil_2' : 0,
		'moist_soil_3' : 0,
		'moist_soil_4' : 0,
		'cstat' : 0,
		'pohstat' : 0,
		'pihstat' : 0,
		'apstat' : 0,
		'efstat' : 0,
		'tbdstat' : 0,
		'cdepth' : 85,
		'pdepth' : 148,
    }
	return render_template('home.html', **templateData)

@app.route("/water")
def water():
	templateData = {
		'title' : 'GPIO Relay Status!',
		'Relay1a'  : 0,
		'Relay2a'  : 0,
		'Relay3a'  : 0,
		'Relay4a'  : 1,
		'Relay5a'  : 0,
		'Relay6a'  : 0,
		'Relay7a'  : 0,
		'Relay8a'  : 0,
		'Relay1b'  : 0,
		'Relay2b'  : 0,
		'Relay3b'  : 0,
		'Relay4b'  : 1,
		'Relay5b'  : 1,
		'Relay6b'  : 0,
		'Relay7b'  : 0,
		'relay8b'  : 1,
		'cputemp'  : 110,
		'valvestemp_data' : 72,
		'headtemp_data' : 72,
		'moist_soil_1' : 0,
		'moist_soil_2' : 0,
		'moist_soil_3' : 0,
		'moist_soil_4' : 0,
		'cstat' : 0,
		'pohstat' : 0,
		'pihstat' : 0,
		'apstat' : 0,
		'efstat' : 0,
		'tbdstat' : 0,
		'cdepth' : 85,
		'pdepth' : 148,
    }
	return render_template('water.html', **templateData)

@app.route("/air")
def air():
	templateData = {
		'title' : 'GPIO Relay Status!',
		'Relay1a'  : 0,
		'Relay2a'  : 0,
		'Relay3a'  : 0,
		'Relay4a'  : 1,
		'Relay5a'  : 0,
		'Relay6a'  : 0,
		'Relay7a'  : 0,
		'Relay8a'  : 0,
		'Relay1b'  : 0,
		'Relay2b'  : 0,
		'Relay3b'  : 0,
		'Relay4b'  : 1,
		'Relay5b'  : 1,
		'Relay6b'  : 0,
		'Relay7b'  : 0,
		'relay8b'  : 1,
		'cputemp'  : 110,
		'valvestemp_data' : 72,
		'headtemp_data' : 72,
		'moist_soil_1' : 0,
		'moist_soil_2' : 0,
		'moist_soil_3' : 0,
		'moist_soil_4' : 0,
		'cstat' : 0,
		'pohstat' : 0,
		'pihstat' : 0,
		'apstat' : 0,
		'efstat' : 0,
		'tbdstat' : 0,
		'cdepth' : 85,
		'pdepth' : 148,
    }
	return render_template('air.html', **templateData)

@app.route("/power")
def power():
	templateData = {
		'title' : 'GPIO Relay Status!',
		'Relay1a'  : 0,
		'Relay2a'  : 0,
		'Relay3a'  : 0,
		'Relay4a'  : 1,
		'Relay5a'  : 0,
		'Relay6a'  : 0,
		'Relay7a'  : 0,
		'Relay8a'  : 0,
		'Relay1b'  : 0,
		'Relay2b'  : 0,
		'Relay3b'  : 0,
		'Relay4b'  : 1,
		'Relay5b'  : 1,
		'Relay6b'  : 0,
		'Relay7b'  : 0,
		'relay8b'  : 1,
		'cputemp'  : 110,
		'valvestemp_data' : 72,
		'headtemp_data' : 72,
		'moist_soil_1' : 0,
		'moist_soil_2' : 0,
		'moist_soil_3' : 0,
		'moist_soil_4' : 0,
		'cstat' : 0,
		'pohstat' : 0,
		'pihstat' : 0,
		'apstat' : 0,
		'efstat' : 0,
		'tbdstat' : 0,
		'cdepth' : 85,
		'pdepth' : 148,
    }
	return render_template('power.html', **templateData)

if __name__ == "__main__":
#   app.run(host='192.168.1.50', port=443, debug=False, ssl_context=('cert.pem', 'key.pem'))
	#app.run(host='192.168.1.50', port=80, debug=True)
	app.run(host='192.168.1.122', port=80, debug=True)
